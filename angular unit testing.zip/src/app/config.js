export const constants = {
    apiUrl: 'http://dummy.restapiexample.com/api/',
}