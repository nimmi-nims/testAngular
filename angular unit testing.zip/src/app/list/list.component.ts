import { Component, OnInit } from '@angular/core';
import { Services } from '../services';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  employees = [];

  constructor(private _services: Services) {}

  ngOnInit() {
    this._services.list().subscribe((res) => {
      this.employees = res.data;
      console.log(res);
    });
  }

}
