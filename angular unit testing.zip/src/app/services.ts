import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { constants } from './config';

@Injectable()
export class Services {
  private _listUrl = constants.apiUrl + 'v1/employees';
  private _detailsUrl = constants.apiUrl + 'v1/employee/';

  constructor(private _http: HttpClient) {}

  list(): Observable<any> {
    return this._http.get<any>(this._listUrl);
  }

  details(id): Observable<any> {
    return this._http.get<any>(`${this._detailsUrl}\${id}`);
  }
}
